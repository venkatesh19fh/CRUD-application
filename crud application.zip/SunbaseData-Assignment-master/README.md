# SunbaseData-Assignment

#### This is the assignment repo, it contains all the files that I worked on and all the files required for the assignment.

### This is the login screen - 
![Login screen](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/ca92f1fd-0314-49c7-87ff-c037fa8220eb)

### This is error page if wrong password is entered - 

![errorpage](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/1588f3cf-c482-47c0-a38a-252e7f7a4393)

### After loggin in, showing detaills - 

![CustomerDetails](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/c577cf76-1759-4baa-b15b-5e449b89571e)

![CustomerDetails](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/80bf950c-c118-4fed-a5e1-1a645e69ec8d)

## Add customer - 
![addCustomer](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/f2f95f1e-0c63-4402-bcdb-cc96d48075cb)

## Delete customer - 
![DeleteCustomer](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/bc1ca682-804e-4dea-b57e-4869d3139b29)

## Update customer - 
![updateCustomer](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/837a657b-b1c1-4939-8bd0-4828c214d4ca)

### Extra feature - If someone tries to jump on any of the pages without loggin in the webfilter would redirect the user to login page : 
### In the URL we can see that the user is requesting to see the customer list
![feature](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/72b397da-ae7a-4ae1-9428-d2408866f1e3)



## Thank You.



